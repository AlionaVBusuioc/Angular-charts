import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radar-chart',
  templateUrl: './radar-chart.component.html',
  styleUrls: ['./radar-chart.component.css']
})
export class RadarChartComponent implements OnInit {

  public radarChartLabels = ['Q1', 'Q2', 'Q3', 'Q4'];
  public radarChartData = [
  {data: [120, 130, 180, 70], label:'2018'},
  {data: [90, 150, 200, 45], label: '2019'}
  ];

  public radarChartType = 'radar';

  constructor() { }

  ngOnInit() {
  }

}
